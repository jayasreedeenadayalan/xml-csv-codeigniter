<?php
class XmlConvertor extends CI_Controller {
	private $document;
	private $filename;

	public function index() {
	    if (!empty($_FILES['inputFile']) && $_FILES['inputFile']['error'] == 0) {
	      $inputFile = $_FILES['inputFile'];
	      $path = FCPATH .'assets/'.$inputFile['name'];
	      move_uploaded_file($inputFile['tmp_name'],$path);
	      $xmlFile = file_get_contents($path);
          $xml = simplexml_load_string($xmlFile);
          $json  = json_encode($xml);
          $xmlArr = json_decode($json, true);
          $newData = !empty($xmlArr['book']) ? $xmlArr['book'] : $xmlArr;
          $this->outputCsv('sample.csv', $newData);
          exit();
        }
        $this->load->view('/xmlconvertor/index');
    }

    public function outputCsv($fileName, $assocDataArray)
    {
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Content-type: text/csv");
        header("Content-Disposition: attachment; filename=\"$fileName\"");
        $fh = fopen( 'php://output', 'w' );
        $heading = false;
        if(!empty($assocDataArray))
            foreach($assocDataArray as $row) {
                if(!$heading) {
                    // output the column headings
                    fputcsv($fh, array_keys($row));
                    $heading = true;
                }
                // loop over the rows, outputting them
                fputcsv($fh, array_values($row));

            }
        fclose($fh);
    }


}
?>
