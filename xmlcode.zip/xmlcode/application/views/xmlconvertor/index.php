<html>
<head>
 <title>Xml to CSV Convertor</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css"></link>
  <script src="<?php echo base_url();?>js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>js/validate.js"></script>

</head>
<body>


<div class="container">
  <h2>XML to CSV Convertor</h2>
  <?php $attributes = array("id"=>"fileLoad");?>
  <?php echo form_open_multipart('',$attributes);?>
    <div class="form-group">
      <label for="fileupload">Select XML File to upload:</label>
	  <?php $data = [
				'type' => 'file',
				'class' => 'form-control',
				'id' => 'inputFile',
				'name' => 'inputFile'
	  ]; ?>
	  <?php echo form_input($data);?>
	  <span id="FilesupErr"></span>
    </div>
    <button type="submit" name="submit"  onclick="return validate();" class="btn btn-success">Submit</button>
  <?php echo form_close();?>
</div>
<script type="text/javascript">
    $(document).ready(function(){
     
        $('input[type="file"]').change(function(e){
            var fileName = e.target.files[0].name;
			$("#FilesupErr").html("");
			var ext = fileName.split('.').pop();
			if(ext != 'xml'){
				$("#FilesupErr").css({'color':'#ff0000'}).html('Please upload xml files only');
				return false;
			}else{
				$("#fileLoad").submit();
				return false;
			}
		});
		return false;
        
    });
</script>

</body>
</html>
