function validate(){
   var files = $("#inputFile").val();
   if(files == ''){
		$("#FilesupErr").css({'color':'#ff0000'}).html('Please upload xml files');
		return false;
   }
}